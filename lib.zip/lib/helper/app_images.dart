class AppImages {
  static const hindiImage = 'assets/hindi.png';
  static const englishImage = 'assets/english.png';
  static const teluguImage = 'assets/telugu.png';
  static const malayalamImage = 'assets/malyalam.png';
  static const kannadaImage = 'assets/kannada.png';
  static const bengaliImage = 'assets/bengali.png';
  static const appLogo = 'assets/login-logo.png';
}
