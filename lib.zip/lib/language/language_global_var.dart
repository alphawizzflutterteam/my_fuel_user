class LanguageGlobalVar {
  static String HELLO_WORLD = "hello_world";
  static String Choose_Language = "choose_language";
}
