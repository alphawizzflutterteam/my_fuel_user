import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:test_prj/data/model/response/setting_model.dart';

class AppBaseController extends GetxController {
  // Observable variable to store API response
}
