class LanguageModel {
  String? title;
  String? image;
  bool? isSelected;

  LanguageModel({this.title, this.image, this.isSelected});
}
